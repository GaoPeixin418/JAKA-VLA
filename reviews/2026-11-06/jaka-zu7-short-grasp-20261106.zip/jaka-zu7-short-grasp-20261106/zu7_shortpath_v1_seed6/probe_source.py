"""Bounded initial-grasp expert experiment; records failures and full-view video."""
import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path('/data/jaka-vla')
REPO = ROOT / 'repos/RoboTwin'
sys.path[:0] = [str(ROOT), str(REPO)]
os.chdir(REPO)
from scripts.eval_policy_xpolicylab import load_task_args, class_decorator
from envs.utils import ArmTag
from eval_v2 import robot_vector
from jaka_vla.review_video import ReviewVideo
from jaka_vla.short_grasp import install_short_grasp


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--seed', type=int, default=6)
    p.add_argument('--original-selector', action='store_true')
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    cfg, _ = load_task_args({'task_name': 'handover_block', 'task_config': 'zu7_smoke', 'policy_name': 'SmolVLA'})
    cfg.update(save_data=False, need_plan=True, eval_mode=False, render_freq=0, save_freq=None)
    task = class_decorator('handover_block')
    task.setup_demo(now_ep_num=args.seed, seed=args.seed, **cfg)
    audit = {} if args.original_selector else install_short_grasp(task)
    video = ReviewVideo(task, args.output/f'seed_{args.seed}_multiview.mp4', 25, 'EXPERT GRASP PATH PROBE', args.seed)
    r = task.robot
    arms = {link.entity.global_id: arm for arm in ('left', 'right') for link in getattr(r, f'{arm}_entity').get_links()}
    t0 = task._jaka_sim_steps
    initial_height = float(task.box.get_pose().p[2])
    step = task._jaka_step
    traces, contacts = [], []
    phase = 'approach'
    held_ticks = longest = 0
    track_ticks = 0
    failure = None
    start_wall = time.perf_counter()
    arm_indices = [*range(6), *range(7, 13)]
    initial_tcp = np.asarray(r.get_left_tcp_pose()[:3])
    first = video.capture(task.get_obs())
    video.write(first, 0, 'INTRO / frozen frame', 50)

    def observe():
        nonlocal held_ticks, longest, track_ticks
        step()
        now = (task._jaka_sim_steps-t0)*.004
        measured = robot_vector(r)
        velocity = robot_vector(r, True)
        commanded = np.r_[r.get_left_arm_jointState(), r.get_right_arm_jointState()]
        fingers = set()
        right_contact = False
        cross = False
        for contact in task.scene.get_contacts():
            impulse = sum(float(np.linalg.norm(point.impulse)) for point in contact.points)
            if impulse <= 1e-5:
                continue
            labels = sorted(f'{arms.get(b.entity.global_id, "scene")}:{b.entity.name}' for b in contact.bodies)
            if not any(arms.get(b.entity.global_id) for b in contact.bodies):
                continue
            contacts.append({'time_s': now, 'pair': labels, 'impulse_ns': impulse})
            if 'scene:box' in labels:
                fingers.update(s for s in labels if s in ('left:finger_left', 'left:finger_right'))
                right_contact |= any(s.startswith('right:') for s in labels)
            cross |= {arms.get(b.entity.global_id) for b in contact.bodies} == {'left', 'right'}
        lift = float(task.box.get_pose().p[2])-initial_height
        held = lift > .05 and .15 < measured[6] < .85 and len(fingers) == 2 and not right_contact
        held_ticks = held_ticks+1 if held else 0
        longest = max(longest, held_ticks)
        error = float(np.abs(commanded-measured)[arm_indices].max())
        track_ticks = track_ticks+1 if error > .12 else 0
        traces.append(np.r_[now, measured, velocity, commanded, r.get_left_tcp_pose(), task.box.get_pose().p,
                               lift, held, error, len(fingers)])
        if (task._jaka_sim_steps-t0) % 10 == 0:
            frame = video.capture(task.get_obs())
            video.write(frame, now, phase+' / expert only')
        if cross:
            raise RuntimeError('interarm_contact')
        if track_ticks >= 10:
            raise RuntimeError('persistent_tracking_error')
    task._jaka_step = observe
    try:
        task.move(task.grasp_actor(task.box, arm_tag=ArmTag('left'), pre_grasp_dis=.07,
                                  grasp_dis=0., contact_point_id=[0, 1, 2, 3]))
        if not task.plan_success:
            raise RuntimeError('grasp_plan_failed')
        phase = 'lift'
        task.move(task.move_by_displacement(ArmTag('left'), z=.1))
        if not task.plan_success:
            raise RuntimeError('lift_plan_failed')
        phase = 'hold 1 second'
        for _ in range(250):
            observe()
    except Exception as exc:
        failure = f'{type(exc).__name__}: {exc}'
        print('PROBE FAILURE', failure, flush=True)
    finally:
        array = np.asarray(traces)
        duration = (task._jaka_sim_steps-t0)*.004
        frame = video.capture(task.get_obs())
        status = 'GRASP VERIFIED / expert only' if longest*.004 >= .6 else 'GRASP NOT VERIFIED'
        if failure:
            status += ' / STOP '+failure
        video.write(frame, duration, status)
        video.write(frame, duration, status+' / FROZEN final frame', 75)
        video.close()
        report = {'seed': args.seed, 'mode': 'expert_grasp_subtask_only', 'selector': 'original' if args.original_selector else 'short_grasp_v1',
                  'grasp_success': longest*.004 >= .6, 'complete_handover_tested': False,
                  'longest_verified_hold_s': longest*.004, 'failure': failure,
                  'sim_seconds': duration, 'wall_seconds': time.perf_counter()-start_wall, 'video': video.metadata(),
                  'grasp_definition': 'lift >5cm, measured aperture 15-85%, bilateral finger impulses >1e-5Ns, no right-arm contact, continuous 0.6s'}
        if len(array):
            # time + measured14 + velocity14 + commanded14 + left_tcp7 + object3 + lift/held/error/fingers
            closed = np.flatnonzero(array[:, 29+6] < .95)
            end = int(closed[0]) if len(closed) else len(array)-1
            tcp = np.vstack([initial_tcp, array[:end+1, 43:46]])
            length = float(np.linalg.norm(np.diff(tcp, axis=0), axis=1).sum())
            direct = float(np.linalg.norm(tcp[-1]-tcp[0]))
            report.update(preclose_tcp_path_m=length, preclose_endpoint_distance_m=direct,
                          preclose_path_ratio=length/max(direct, 1e-9),
                          max_lift_m=float(array[:,53].max()),
                          joint_speed_peak_rad_s=float(np.abs(array[:,15:29][:,arm_indices]).max()),
                          tracking_error_peak_rad=float(array[:,55].max()),
                          interarm_contact_samples=sum(any(s.startswith('left:') for s in c['pair']) and any(s.startswith('right:') for s in c['pair']) for c in contacts))
        np.savez_compressed(args.output/'trace.npz', trace=array)
        (args.output/'trace_schema.json').write_text(json.dumps(['time_s','measured_position[14]','measured_velocity[14]','commanded_position[14]','left_tcp[7]','object_xyz[3]','lift_m','held','tracking_error_rad','finger_count'], indent=2))
        (args.output/'selection.json').write_text(json.dumps(audit, indent=2)+'\n')
        (args.output/'contacts.json').write_text(json.dumps(contacts, indent=2)+'\n')
        (args.output/'result.json').write_text(json.dumps(report, indent=2)+'\n')
        print(json.dumps(report), flush=True)
        task.close_env(clear_cache=True)


if __name__ == '__main__':
    main()
